# MLflow MongoDB Plugin

Pure MongoDB tracking store for MLflow 3.x with full OpenTelemetry tracing support and custom Prompt Registry.

## Features

- ✅ **Zero SQL dependencies** - Pure MongoDB backend
- ✅ **MLflow 3.x OTel tracing** - Full span tree, attributes, events, links
- ✅ **Prompt Registry** - Versioning, aliases, Jinja2 templates (no Databricks required)
- ✅ **Model Registry** - MongoDB-backed registered models and versions
- ✅ **Complete AbstractStore** - All methods implemented for UI compatibility
- ✅ **Streamlit Dashboard** - Alternative UI if MLflow UI has issues
- ✅ **Docker Compose** - One-command deployment

## Quick Start

```bash
# Clone and install
git clone https://github.com/yourusername/mlflow-mongodb-plugin.git
cd mlflow-mongodb-plugin
pip install -e ".[ui]"

# Start MongoDB + MLflow UI
docker-compose -f docker/docker-compose.yml up -d

# Set tracking URI
export MLFLOW_TRACKING_URI="mongodb://admin:adminpassword@localhost:27017/mlflow_db?authSource=admin"

# Use MLflow normally
python examples/llm_tracing.py
```

## Streamlit Dashboard (Alternative UI)

If the MLflow UI has compatibility issues, use the Streamlit dashboard:

```bash
pip install -e ".[ui]"
streamlit run streamlit_ui/app.py
```

This provides a clean interface for viewing experiments, runs, traces, and prompts directly from MongoDB.

## Prompt Registry Usage

```python
from mlflow_mongodb import MongoDBPromptRegistry
from pymongo import MongoClient

registry = MongoDBPromptRegistry(MongoClient()["mlflow_db"])

# Register prompt
v1 = registry.register_prompt(
    name="customer_support",
    template="Answer: {{question}}",
    tags={"team": "support"}
)

# Set alias
registry.set_prompt_alias("customer_support", "production", 1)

# Load and format
prompt = registry.load_prompt("prompts:/customer_support@production")
response = prompt.format(question="How do I reset my password?")
```

## Architecture

```
┌─────────────┐     REST API      ┌─────────────────────┐
│  MLflow UI  │ ────────────────→ │  MLflow Server      │
│  (React)    │                   │  ┌───────────────┐  │
└─────────────┘                   │  │ MongoDB Store │  │
       │                          │  │ (Plugin)      │  │
       │                          │  └───────────────┘  │
       │                          └─────────────────────┘
       │                                   │
       │ Fallback                          ↓
       │                          ┌────────────┐
       └─────────────────────────→│  MongoDB   │
              Streamlit           │  (Single   │
              Dashboard           │  Source)   │
                                  └────────────┘
```

## Collections

| Collection | Purpose |
|---|---|
| `experiments` | Experiment metadata |
| `runs` | Run metadata and status |
| `metrics` | Time-series metrics |
| `params` | Run parameters |
| `tags` | Run/experiment tags |
| `traces` | Trace info (MLflow 3.x) |
| `spans` | OTel spans |
| `assessments` | Human/LLM feedback |
| `prompts` | Prompt metadata |
| `prompt_versions` | Prompt versions |
| `prompt_aliases` | Prompt aliases |
| `registered_models` | Model registry |
| `model_versions` | Model versions |

## License

Apache 2.0
