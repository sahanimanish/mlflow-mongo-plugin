"""Tests for MongoDB Prompt Registry."""

import pytest
from mlflow_mongodb.prompt_registry import MongoDBPromptRegistry, PromptVersion


class TestPromptRegistry:
    def test_register_prompt(self, mock_db):
        registry = MongoDBPromptRegistry(mock_db)
        pv = registry.register_prompt(
            name="test_prompt",
            template="Hello {{name}}!",
            commit_message="Initial version",
            tags={"team": "ai"},
        )

        assert pv.name == "test_prompt"
        assert pv.version == 1
        assert pv.template == "Hello {{name}}!"
        assert pv.tags == {"team": "ai"}

    def test_register_multiple_versions(self, mock_db):
        registry = MongoDBPromptRegistry(mock_db)
        v1 = registry.register_prompt("multi_version", "v1 template")
        v2 = registry.register_prompt("multi_version", "v2 template")

        assert v1.version == 1
        assert v2.version == 2

    def test_load_prompt(self, mock_db):
        registry = MongoDBPromptRegistry(mock_db)
        registry.register_prompt("load_test", "template {{x}}")

        loaded = registry.load_prompt("load_test")
        assert loaded.name == "load_test"
        assert loaded.version == 1

    def test_load_prompt_with_version(self, mock_db):
        registry = MongoDBPromptRegistry(mock_db)
        registry.register_prompt("versioned", "v1")
        registry.register_prompt("versioned", "v2")

        loaded = registry.load_prompt("versioned", version=2)
        assert loaded.template == "v2"

    def test_set_alias(self, mock_db):
        registry = MongoDBPromptRegistry(mock_db)
        registry.register_prompt("aliased", "template")
        registry.set_prompt_alias("aliased", "production", 1)

        loaded = registry.load_prompt("prompts:/aliased@production")
        assert loaded.version == 1

    def test_format_prompt(self, mock_db):
        registry = MongoDBPromptRegistry(mock_db)
        registry.register_prompt("format_test", "Hello {{name}}!")

        pv = registry.load_prompt("format_test")
        result = pv.format(name="World")
        assert result == "Hello World!"

    def test_format_chat_prompt(self, mock_db):
        registry = MongoDBPromptRegistry(mock_db)
        template = [
            {"role": "system", "content": "You are {{role}}"},
            {"role": "user", "content": "{{question}}"},
        ]
        registry.register_prompt("chat_prompt", template)

        pv = registry.load_prompt("chat_prompt")
        result = pv.format(role="helpful", question="Hello")
        assert result[0]["content"] == "You are helpful"
        assert result[1]["content"] == "Hello"

    def test_search_prompts(self, mock_db):
        registry = MongoDBPromptRegistry(mock_db)
        registry.register_prompt("search_a", "template", tags={"team": "ai"})
        registry.register_prompt("search_b", "template", tags={"team": "ml"})

        results = registry.search_prompts("tags.team = 'ai'")
        assert len(results) == 1
        assert results[0].name == "search_a"

    def test_delete_prompt(self, mock_db):
        registry = MongoDBPromptRegistry(mock_db)
        registry.register_prompt("to_delete", "template")
        registry.delete_prompt("to_delete")

        assert registry.load_prompt("to_delete", allow_missing=True) is None
