"""Tests for MongoDB Tracking Store."""

import pytest
from mlflow.entities import RunTag
from mlflow_mongodb.tracking_store import MongoDBTrackingStore


class TestTrackingStore:
    def test_create_experiment(self, mock_db):
        store = MongoDBTrackingStore("mongodb://localhost:27017/test", "/tmp/artifacts")
        store.db = mock_db  # Override with mock
        store._create_indexes()

        exp_id = store.create_experiment("test_exp")
        assert exp_id is not None

        exp = store.get_experiment(exp_id)
        assert exp.name == "test_exp"

    def test_create_run(self, mock_db):
        store = MongoDBTrackingStore("mongodb://localhost:27017/test", "/tmp/artifacts")
        store.db = mock_db
        store._create_indexes()

        exp_id = store.create_experiment("run_test")
        run = store.create_run(exp_id, "user", 12345, [RunTag("key", "value")])

        assert run.info.run_id is not None
        assert run.info.experiment_id == exp_id

    def test_log_metric(self, mock_db):
        store = MongoDBTrackingStore("mongodb://localhost:27017/test", "/tmp/artifacts")
        store.db = mock_db
        store._create_indexes()

        exp_id = store.create_experiment("metric_test")
        run = store.create_run(exp_id, "user", 12345, [])

        from mlflow.entities import Metric
        store.log_metric(run.info.run_id, Metric("acc", 0.95, 12345, 0))

        history = store.get_metric_history(run.info.run_id, "acc")
        assert len(history) == 1
        assert history[0].value == 0.95

    def test_search_runs(self, mock_db):
        store = MongoDBTrackingStore("mongodb://localhost:27017/test", "/tmp/artifacts")
        store.db = mock_db
        store._create_indexes()

        exp_id = store.create_experiment("search_test")
        store.create_run(exp_id, "user", 12345, [])
        store.create_run(exp_id, "user", 12346, [])

        runs, _ = store.search_runs([exp_id])
        assert len(runs) == 2
