"""Pytest configuration and fixtures."""

import pytest
from mongomock import MongoClient as MockMongoClient


@pytest.fixture
def mock_db():
    """Provide a mock MongoDB database."""
    client = MockMongoClient()
    db = client["test_mlflow"]
    yield db
    client.close()
