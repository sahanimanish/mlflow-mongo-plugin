"""Complex multi-span trace example showing full OTel capabilities."""

import mlflow
from mlflow.entities import SpanType

mlflow.set_tracking_uri("mongodb://localhost:27017/mlflow_db")
mlflow.set_experiment("multi_span_demo")


@mlflow.trace(span_type=SpanType.AGENT)
def rag_pipeline(query: str):
    """RAG pipeline with full observability."""

    # Step 1: Query understanding
    with mlflow.start_span(name="query_analysis", span_type=SpanType.PARSER) as span:
        intent = "informational"
        entities = ["password", "reset"]
        span.set_outputs({"intent": intent, "entities": entities})

    # Step 2: Document retrieval
    with mlflow.start_span(name="retrieval", span_type=SpanType.RETRIEVER) as span:
        # Simulate vector search
        docs = [
            {"id": "doc1", "score": 0.95, "content": "To reset your password..."},
            {"id": "doc2", "score": 0.87, "content": "Password policies..."},
        ]
        span.set_outputs({"retrieved_docs": docs, "top_k": 2})
        # Add retrieval metrics as attributes
        span.set_attributes({"retrieval.latency_ms": 45, "retrieval.num_docs": len(docs)})

    # Step 3: Reranking
    with mlflow.start_span(name="rerank", span_type=SpanType.TOOL) as span:
        reranked = sorted(docs, key=lambda x: x["score"], reverse=True)
        span.set_outputs({"reranked_docs": reranked})

    # Step 4: LLM generation
    with mlflow.start_span(name="generate", span_type=SpanType.LLM) as span:
        context = "\n".join([d["content"] for d in reranked[:2]])
        prompt = f"Context: {context}\n\nQuestion: {query}\n\nAnswer:"

        # Simulate LLM call
        response = "To reset your password, go to Settings > Security > Change Password."

        span.set_inputs({"prompt": prompt})
        span.set_outputs({"response": response})
        span.set_attributes({
            "llm.model": "gpt-4",
            "llm.temperature": 0.7,
            "llm.tokens_input": 150,
            "llm.tokens_output": 25,
            "llm.cost_usd": 0.003,
        })

    # Step 5: Post-processing
    with mlflow.start_span(name="post_process", span_type=SpanType.TOOL) as span:
        final_response = response + "\n\nIf you need further help, contact support@example.com"
        span.set_outputs({"final_response": final_response})

    return final_response


# Execute the pipeline
result = rag_pipeline("How do I reset my password?")
print(f"Final response:\n{result}")

# The complete trace with all 5 spans is now in MongoDB
# Each span has full OTel attributes, inputs, outputs, and timing
