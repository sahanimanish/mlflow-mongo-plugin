"""LLM tracing example with OpenTelemetry spans."""

import mlflow
from mlflow.entities import SpanType

mlflow.set_tracking_uri("mongodb://localhost:27017/mlflow_db")
mlflow.set_experiment("llm_tracing_demo")


@mlflow.trace(span_type=SpanType.AGENT)
def customer_support_agent(query: str):
    """A simple customer support agent with tracing."""

    # Retrieval step
    with mlflow.start_span(name="retrieve_docs", span_type=SpanType.RETRIEVER) as span:
        docs = ["FAQ #1: How to reset password", "FAQ #2: How to update billing"]
        span.set_outputs({"documents": docs})

    # LLM generation step
    with mlflow.start_span(name="generate_response", span_type=SpanType.LLM) as span:
        response = f"Based on our docs, here is the answer to: {query}"
        span.set_inputs({"query": query, "context": docs})
        span.set_outputs({"response": response})

    return response


# Run the agent
result = customer_support_agent("How do I reset my password?")
print(f"Agent response: {result}")

# The trace is now stored in MongoDB with full OTel span data
# View it in the MLflow UI at http://localhost:5000
