"""Prompt Registry usage example."""

from mlflow_mongodb import MongoDBPromptRegistry
from pymongo import MongoClient

# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017")
registry = MongoDBPromptRegistry(client["mlflow_db"])

# Register a simple prompt
v1 = registry.register_prompt(
    name="customer_support",
    template="You are a helpful support agent. Answer: {{question}}",
    commit_message="Initial version",
    tags={"team": "support", "language": "en"},
)
print(f"Registered version {v1.version}")

# Register an improved version
v2 = registry.register_prompt(
    name="customer_support",
    template="""You are an expert customer support agent with 10 years of experience.
Be empathetic, clear, and concise in your response.

Customer question: {{question}}

Response:""",
    commit_message="More professional and empathetic tone",
    tags={"team": "support", "language": "en"},
)
print(f"Registered version {v2.version}")

# Set aliases
registry.set_prompt_alias("customer_support", "production", 1)
registry.set_prompt_alias("customer_support", "staging", 2)

# Load prompts
prod_prompt = registry.load_prompt("prompts:/customer_support@production")
staging_prompt = registry.load_prompt("prompts:/customer_support@staging")

print(f"\nProduction prompt (v{prod_prompt.version}):")
print(prod_prompt.template[:100] + "...")

print(f"\nStaging prompt (v{staging_prompt.version}):")
print(staging_prompt.template[:100] + "...")

# Format a prompt
response = staging_prompt.format(question="How do I reset my password?")
print(f"\nFormatted response template:\n{response}")

# List all versions
versions = registry.get_all_versions("customer_support")
print(f"\nTotal versions: {len(versions)}")
for v in versions:
    print(f"  v{v.version}: {v.commit_message}")

# List aliases
aliases = registry.get_aliases("customer_support")
print(f"\nAliases: {aliases}")
