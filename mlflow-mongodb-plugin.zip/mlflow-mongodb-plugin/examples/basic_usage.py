"""Basic usage example for MLflow MongoDB Plugin."""

import mlflow
from mlflow.entities import SpanType

# Set tracking URI to MongoDB
mlflow.set_tracking_uri("mongodb://localhost:27017/mlflow_db")

# Create experiment
experiment_id = mlflow.create_experiment("my_experiment")
mlflow.set_experiment("my_experiment")

# Log a run
with mlflow.start_run():
    mlflow.log_param("learning_rate", 0.01)
    mlflow.log_param("epochs", 100)

    for epoch in range(10):
        mlflow.log_metric("loss", 1.0 / (epoch + 1), step=epoch)
        mlflow.log_metric("accuracy", 0.5 + epoch * 0.05, step=epoch)

print("Run logged successfully!")
