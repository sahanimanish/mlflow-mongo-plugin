"""
MLflow MongoDB Plugin - Pure MongoDB tracking store for MLflow 3.x.

Supports:
- Full OTel-native tracing (spans, traces, assessments)
- Prompt Registry with versioning and aliases
- Model Registry (MongoDB-backed)
- Zero SQL dependencies
"""

__version__ = "0.3.0"

from .tracking_store import MongoDBTrackingStore
from .prompt_registry import MongoDBPromptRegistry, PromptVersion

__all__ = [
    "MongoDBTrackingStore",
    "MongoDBPromptRegistry",
    "PromptVersion",
]
