"""
Custom Prompt Registry backed by MongoDB.
Implements MLflow-compatible prompt versioning without Databricks/Unity Catalog.
"""

import json
import logging
import re
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Optional

from jinja2 import SandboxedEnvironment
from mlflow.exceptions import MlflowException
from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE, RESOURCE_DOES_NOT_EXIST

logger = logging.getLogger(__name__)


@dataclass
class PromptVersion:
    """Represents a single version of a prompt."""

    name: str
    version: int
    template: str | list[dict]
    commit_message: str = ""
    tags: dict[str, str] = field(default_factory=dict)
    model_config: Optional[dict] = None
    response_format: Optional[Any] = None
    created_at: int = 0
    created_by: str = "unknown"

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "version": self.version,
            "template": self.template,
            "commit_message": self.commit_message,
            "tags": self.tags,
            "model_config": self.model_config,
            "response_format": self.response_format,
            "created_at": self.created_at,
            "created_by": self.created_by,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "PromptVersion":
        return cls(
            name=d["name"],
            version=d["version"],
            template=d["template"],
            commit_message=d.get("commit_message", ""),
            tags=d.get("tags", {}),
            model_config=d.get("model_config"),
            response_format=d.get("response_format"),
            created_at=d.get("created_at", 0),
            created_by=d.get("created_by", "unknown"),
        )

    def format(self, **kwargs) -> str | list[dict]:
        """
        Format the prompt template with variables.
        Supports {{variable}} syntax and Jinja2 for advanced templates.
        """
        template = self.template

        # Check if it's a Jinja2 template (contains {% %})
        if isinstance(template, str) and "{%" in template:
            env = SandboxedEnvironment()
            jinja_template = env.from_string(template)
            return jinja_template.render(**kwargs)

        # Simple double-brace substitution
        if isinstance(template, str):
            result = template
            for key, value in kwargs.items():
                result = result.replace(f"{{{{{key}}}}}", str(value))
            return result

        # Chat/conversation format
        if isinstance(template, list):
            formatted = []
            for msg in template:
                content = msg.get("content", "")
                for key, value in kwargs.items():
                    content = content.replace(f"{{{{{key}}}}}", str(value))
                formatted.append({"role": msg["role"], "content": content})
            return formatted

        return template

    def to_single_brace_format(self) -> str:
        """Convert {{variable}} to {variable} for LangChain/LlamaIndex compatibility."""
        if isinstance(self.template, str):
            return re.sub(r"\{\{(\w+)\}\}", r"{\1}", self.template)
        return self.template


class MongoDBPromptRegistry:
    """
    Prompt Registry backed by MongoDB.
    Provides MLflow-compatible API for prompt versioning.
    """

    def __init__(self, db):
        self.db = db
        self.prompts = db["prompts"]  # Stores prompt metadata
        self.prompt_versions = db["prompt_versions"]  # Stores versions
        self.prompt_aliases = db["prompt_aliases"]  # Stores aliases

        # Create indexes
        self.prompts.create_index("name", unique=True)
        self.prompt_versions.create_index([("name", 1), ("version", 1)], unique=True)
        self.prompt_aliases.create_index([("name", 1), ("alias", 1)], unique=True)

    # ========================================================================
    # CORE API (matches mlflow.genai.*)
    # ========================================================================

    def register_prompt(
        self,
        name: str,
        template: str | list[dict],
        commit_message: str = "",
        tags: Optional[dict[str, str]] = None,
        model_config: Optional[dict] = None,
        response_format: Optional[Any] = None,
        created_by: str = "unknown",
    ) -> PromptVersion:
        """
        Register a new prompt or create a new version of an existing prompt.
        """
        # Validate name format (allow any format, not just UC)
        if not name or not isinstance(name, str):
            raise MlflowException(
                "Prompt name must be a non-empty string", INVALID_PARAMETER_VALUE
            )

        # Check if prompt exists
        prompt_doc = self.prompts.find_one({"name": name})

        if prompt_doc:
            # Increment version
            next_version = prompt_doc.get("latest_version", 0) + 1
        else:
            # Create new prompt
            next_version = 1
            self.prompts.insert_one(
                {
                    "name": name,
                    "latest_version": 1,
                    "created_at": int(time.time() * 1000),
                    "created_by": created_by,
                }
            )

        # Create version
        version_doc = {
            "name": name,
            "version": next_version,
            "template": template,
            "commit_message": commit_message,
            "tags": tags or {},
            "model_config": model_config,
            "response_format": response_format,
            "created_at": int(time.time() * 1000),
            "created_by": created_by,
        }
        self.prompt_versions.insert_one(version_doc)

        # Update latest version
        self.prompts.update_one(
            {"name": name}, {"$set": {"latest_version": next_version}}
        )

        logger.info(f"Registered prompt '{name}' version {next_version}")
        return PromptVersion.from_dict(version_doc)

    def load_prompt(
        self,
        name_or_uri: str,
        version: Optional[int | str] = None,
        allow_missing: bool = False,
    ) -> Optional[PromptVersion]:
        """
        Load a prompt by name or URI.
        Supports:
            - load_prompt("my_prompt", version=2)
            - load_prompt("prompts:/my_prompt/2")
            - load_prompt("prompts:/my_prompt@production")
        """
        # Parse URI format
        name, version_or_alias = self._parse_prompt_uri(name_or_uri, version)

        if not name:
            if allow_missing:
                return None
            raise MlflowException(
                f"Invalid prompt URI: {name_or_uri}", INVALID_PARAMETER_VALUE
            )

        # Check if it's an alias
        if isinstance(version_or_alias, str) and not version_or_alias.isdigit():
            alias_doc = self.prompt_aliases.find_one(
                {"name": name, "alias": version_or_alias}
            )
            if not alias_doc:
                if allow_missing:
                    return None
                raise MlflowException(
                    f"Alias '{version_or_alias}' not found for prompt '{name}'",
                    RESOURCE_DOES_NOT_EXIST,
                )
            version_num = alias_doc["version"]
        else:
            version_num = int(version_or_alias) if version_or_alias else None

        # If no version specified, load latest
        if version_num is None:
            prompt_doc = self.prompts.find_one({"name": name})
            if not prompt_doc:
                if allow_missing:
                    return None
                raise MlflowException(
                    f"Prompt '{name}' not found", RESOURCE_DOES_NOT_EXIST
                )
            version_num = prompt_doc.get("latest_version", 1)

        # Load version
        version_doc = self.prompt_versions.find_one(
            {"name": name, "version": version_num}
        )
        if not version_doc:
            if allow_missing:
                return None
            raise MlflowException(
                f"Prompt '{name}' version {version_num} not found",
                RESOURCE_DOES_NOT_EXIST,
            )

        return PromptVersion.from_dict(version_doc)

    def search_prompts(
        self,
        filter_string: Optional[str] = None,
        max_results: int = 100,
        page_token: Optional[str] = None,
    ) -> list[PromptVersion]:
        """
        Search prompts by filter.
        """
        query = {}
        if filter_string:
            # Simple filter parsing
            if "name =" in filter_string:
                match = re.search(r"name\s*=\s*['"]([^'"]+)['"]", filter_string)
                if match:
                    query["name"] = match.group(1)
            elif "tags." in filter_string:
                match = re.search(r"tags\.(\w+)\s*=\s*['"]([^'"]+)['"]", filter_string)
                if match:
                    query[f"tags.{match.group(1)}"] = match.group(2)

        cursor = (
            self.prompt_versions.find(query).limit(max_results).sort("created_at", -1)
        )
        return [PromptVersion.from_dict(d) for d in cursor]

    def set_prompt_alias(self, name: str, alias: str, version: int) -> None:
        """Set an alias (e.g., 'production', 'staging') to a specific version."""
        # Verify version exists
        version_doc = self.prompt_versions.find_one(
            {"name": name, "version": version}
        )
        if not version_doc:
            raise MlflowException(
                f"Prompt '{name}' version {version} not found",
                RESOURCE_DOES_NOT_EXIST,
            )

        self.prompt_aliases.replace_one(
            {"name": name, "alias": alias},
            {
                "name": name,
                "alias": alias,
                "version": version,
                "updated_at": int(time.time() * 1000),
            },
            upsert=True,
        )
        logger.info(f"Set alias '{alias}' for prompt '{name}' -> version {version}")

    def delete_prompt_alias(self, name: str, alias: str) -> None:
        """Delete an alias."""
        self.prompt_aliases.delete_one({"name": name, "alias": alias})

    def delete_prompt_version(self, name: str, version: int) -> None:
        """Delete a specific version."""
        self.prompt_versions.delete_one({"name": name, "version": version})

    def delete_prompt(self, name: str) -> None:
        """Delete a prompt and all its versions/aliases."""
        self.prompts.delete_one({"name": name})
        self.prompt_versions.delete_many({"name": name})
        self.prompt_aliases.delete_many({"name": name})

    # ========================================================================
    # TAG & MODEL CONFIG MANAGEMENT
    # ========================================================================

    def set_prompt_tag(self, name: str, key: str, value: str) -> None:
        """Set a tag on the prompt (applies to all versions)."""
        self.prompts.update_one(
            {"name": name},
            {"$set": {f"tags.{key}": value, "updated_at": int(time.time() * 1000)}},
        )

    def get_prompt_tags(self, name: str) -> dict:
        """Get all tags for a prompt."""
        doc = self.prompts.find_one({"name": name}, {"tags": 1})
        return doc.get("tags", {}) if doc else {}

    def delete_prompt_tag(self, name: str, key: str) -> None:
        """Delete a tag from a prompt."""
        self.prompts.update_one({"name": name}, {"$unset": {f"tags.{key}": ""}})

    def set_prompt_version_tag(self, name: str, version: int, key: str, value: str) -> None:
        """Set a tag on a specific version."""
        self.prompt_versions.update_one(
            {"name": name, "version": version}, {"$set": {f"tags.{key}": value}}
        )

    def delete_prompt_version_tag(self, name: str, version: int, key: str) -> None:
        """Delete a tag from a specific version."""
        self.prompt_versions.update_one(
            {"name": name, "version": version}, {"$unset": {f"tags.{key}": ""}}
        )

    def set_prompt_model_config(self, name: str, version: int, model_config: dict) -> None:
        """Set model config for a specific version."""
        self.prompt_versions.update_one(
            {"name": name, "version": version}, {"$set": {"model_config": model_config}}
        )

    def delete_prompt_model_config(self, name: str, version: int) -> None:
        """Delete model config from a version."""
        self.prompt_versions.update_one(
            {"name": name, "version": version}, {"$unset": {"model_config": ""}}
        )

    # ========================================================================
    # INTERNAL HELPERS
    # ========================================================================

    def _parse_prompt_uri(
        self, uri: str, explicit_version: Optional[int | str] = None
    ) -> tuple[str, Optional[str]]:
        """Parse prompt URI formats."""
        # Format: prompts:/name/version or prompts:/name@alias
        if uri.startswith("prompts:/"):
            uri = uri[9:]  # Remove "prompts:/"

        # Check for @alias
        if "@" in uri:
            parts = uri.split("@")
            return parts[0], parts[1]

        # Check for /version
        if "/" in uri:
            parts = uri.rsplit("/", 1)
            return parts[0], parts[1]

        # Just name
        return uri, str(explicit_version) if explicit_version else None

    def get_all_versions(self, name: str) -> list[PromptVersion]:
        """Get all versions of a prompt."""
        cursor = self.prompt_versions.find({"name": name}).sort("version", 1)
        return [PromptVersion.from_dict(d) for d in cursor]

    def get_aliases(self, name: str) -> dict[str, int]:
        """Get all aliases for a prompt."""
        cursor = self.prompt_aliases.find({"name": name})
        return {d["alias"]: d["version"] for d in cursor}
