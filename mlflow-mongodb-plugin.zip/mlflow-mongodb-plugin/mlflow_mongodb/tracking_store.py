"""
Pure MongoDB Tracking Store for MLflow 3.x.
Implements ALL AbstractStore methods with zero SQL dependencies.
"""

import json
import logging
import time
import uuid
from datetime import datetime
from typing import Any, Literal, Optional

import pymongo
from mlflow.entities import (
    Assessment,
    DatasetInput,
    Experiment,
    LoggedModel,
    Metric,
    Param,
    Run,
    RunData,
    RunInfo,
    RunTag,
    Span,
    Trace,
    TraceData,
    TraceInfo,
    ViewType,
)
from mlflow.entities.model_registry import PromptVersion as MLflowPromptVersion
from mlflow.entities.trace_location import MlflowExperimentLocation
from mlflow.entities.trace_state import TraceState
from mlflow.exceptions import MlflowException
from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE, RESOURCE_DOES_NOT_EXIST
from mlflow.store.entities.paged_list import PagedList
from mlflow.store.tracking import (
    MAX_RESULTS_QUERY_TRACE_METRICS,
    SEARCH_MAX_RESULTS_DEFAULT,
    SEARCH_TRACES_DEFAULT_MAX_RESULTS,
)
from mlflow.store.tracking.abstract_store import AbstractStore
from mlflow.store.workspace.abstract_store import ResolvedTraceArchivalConfig
from mlflow.tracing.analysis import TraceFilterCorrelationResult

from .prompt_registry import MongoDBPromptRegistry

logger = logging.getLogger(__name__)


class MongoDBTrackingStore(AbstractStore):
    """
    Pure MongoDB tracking store for MLflow 3.x.

    Zero SQL dependencies. All data stored in MongoDB.
    Supports experiments, runs, metrics, params, tags, traces, spans,
    assessments, datasets, logged models, model registry, prompt registry,
    scorers, review queues, label schemas, and issues.

    Usage:
        export MLFLOW_TRACKING_URI="mongodb://localhost:27017/mlflow_db"
        mlflow server --backend-store-uri "$MLFLOW_TRACKING_URI" --port 5000
    """

    def __init__(self, store_uri: str, artifact_uri: str):
        super().__init__()
        self.store_uri = store_uri
        self.artifact_uri = artifact_uri

        # Parse MongoDB URI
        parsed = pymongo.uri_parser.parse_uri(store_uri)
        self.db_name = parsed.get("database") or "mlflow"

        import urllib.parse
        url_parsed = urllib.parse.urlparse(store_uri)
        qs = urllib.parse.parse_qs(url_parsed.query)
        self.prefix = qs.get("collection", [""])[0] or ""

        # MongoDB client with production settings
        self.client = pymongo.MongoClient(
            store_uri,
            maxPoolSize=100,
            minPoolSize=10,
            maxIdleTimeMS=45000,
            serverSelectionTimeoutMS=5000,
        )

        # Verify connection
        self.client.admin.command("ping")
        self.db = self.client[self.db_name]

        # Collections
        self.experiments = self.db[f"{self.prefix}experiments"]
        self.runs = self.db[f"{self.prefix}runs"]
        self.metrics = self.db[f"{self.prefix}metrics"]
        self.params = self.db[f"{self.prefix}params"]
        self.tags = self.db[f"{self.prefix}tags"]
        self.traces = self.db[f"{self.prefix}traces"]
        self.spans = self.db[f"{self.prefix}spans"]
        self.assessments = self.db[f"{self.prefix}assessments"]
        self.datasets = self.db[f"{self.prefix}datasets"]
        self.logged_models = self.db[f"{self.prefix}logged_models"]
        self.registered_models = self.db[f"{self.prefix}registered_models"]
        self.model_versions = self.db[f"{self.prefix}model_versions"]
        self.scorers = self.db[f"{self.prefix}scorers"]
        self.label_schemas = self.db[f"{self.prefix}label_schemas"]
        self.review_queues = self.db[f"{self.prefix}review_queues"]
        self.issues = self.db[f"{self.prefix}issues"]

        # Initialize prompt registry
        self.prompt_registry = MongoDBPromptRegistry(self.db)

        self._create_indexes()
        logger.info(f"MongoDBTrackingStore initialized: db={self.db_name}")

    def _create_indexes(self):
        """Create all indexes for optimal performance."""
        # Experiments
        self.experiments.create_index("experiment_id", unique=True)
        self.experiments.create_index("name", unique=True)
        self.experiments.create_index("lifecycle_stage")

        # Runs
        self.runs.create_index("run_id", unique=True)
        self.runs.create_index("experiment_id")
        self.runs.create_index([("status", 1), ("start_time", -1)])
        self.runs.create_index("start_time")

        # Metrics
        self.metrics.create_index([("run_id", 1), ("key", 1), ("timestamp", -1)])
        self.metrics.create_index([("run_id", 1), ("timestamp", -1)])

        # Params & Tags
        self.params.create_index([("run_id", 1), ("key", 1)], unique=True)
        self.tags.create_index([("run_id", 1), ("key", 1)], unique=True)

        # Traces
        self.traces.create_index("trace_id", unique=True)
        self.traces.create_index([("experiment_id", 1), ("request_time", -1)])
        self.traces.create_index([("state", 1), ("request_time", -1)])
        self.traces.create_index("client_request_id")

        # Spans
        self.spans.create_index("span_id", unique=True)
        self.spans.create_index([("trace_id", 1), ("start_time_unix_nano", 1)])
        self.spans.create_index([("trace_id", 1), ("parent_span_id", 1)])
        self.spans.create_index("name")

        # Assessments
        self.assessments.create_index([("trace_id", 1), ("name", 1)], unique=True)

        # Model Registry
        self.registered_models.create_index("name", unique=True)
        self.model_versions.create_index([("name", 1), ("version", 1)], unique=True)

        # Datasets
        self.datasets.create_index("dataset_id", unique=True)

        # Logged Models
        self.logged_models.create_index("model_id", unique=True)

        logger.info("All MongoDB indexes created")

    # ========================================================================
    # EXPERIMENTS
    # ========================================================================

    def search_experiments(
        self,
        view_type: int = ViewType.ALL,
        max_results: int = SEARCH_MAX_RESULTS_DEFAULT,
        filter_string: Optional[str] = None,
        order_by: Optional[list[str]] = None,
        page_token: Optional[str] = None,
    ):
        query = {}
        if view_type == ViewType.ACTIVE_ONLY:
            query["lifecycle_stage"] = "active"
        elif view_type == ViewType.DELETED_ONLY:
            query["lifecycle_stage"] = "deleted"

        cursor = self.experiments.find(query).limit(max_results)
        experiments = [self._doc_to_experiment(d) for d in cursor]
        return experiments, None

    def create_experiment(
        self, name: str, artifact_location: Optional[str] = None, tags: Optional[list] = None
    ) -> str:
        if self.experiments.find_one({"name": name}):
            raise MlflowException(
                f"Experiment '{name}' already exists.", INVALID_PARAMETER_VALUE
            )

        experiment_id = str(uuid.uuid4())
        now_ms = int(time.time() * 1000)

        exp_doc = {
            "experiment_id": experiment_id,
            "name": name,
            "artifact_location": artifact_location or f"{self.artifact_uri}/{experiment_id}",
            "lifecycle_stage": "active",
            "creation_time": now_ms,
            "last_update_time": now_ms,
            "tags": {t.key: t.value for t in (tags or [])},
        }
        self.experiments.insert_one(exp_doc)
        return experiment_id

    def get_experiment(self, experiment_id: str) -> Optional[Experiment]:
        doc = self.experiments.find_one({"experiment_id": experiment_id})
        return self._doc_to_experiment(doc) if doc else None

    def get_experiment_by_name(self, name: str) -> Optional[Experiment]:
        doc = self.experiments.find_one({"name": name})
        return self._doc_to_experiment(doc) if doc else None

    def delete_experiment(self, experiment_id: str):
        self.experiments.update_one(
            {"experiment_id": experiment_id},
            {"$set": {"lifecycle_stage": "deleted", "last_update_time": int(time.time() * 1000)}},
        )

    def restore_experiment(self, experiment_id: str):
        self.experiments.update_one(
            {"experiment_id": experiment_id},
            {"$set": {"lifecycle_stage": "active", "last_update_time": int(time.time() * 1000)}},
        )

    def rename_experiment(self, experiment_id: str, new_name: str):
        self.experiments.update_one(
            {"experiment_id": experiment_id},
            {"$set": {"name": new_name, "last_update_time": int(time.time() * 1000)}},
        )

    def set_experiment_tag(self, experiment_id: str, tag: RunTag):
        self.experiments.update_one(
            {"experiment_id": experiment_id},
            {
                "$set": {
                    f"tags.{tag.key}": tag.value,
                    "last_update_time": int(time.time() * 1000),
                }
            },
        )

    def delete_experiment_tag(self, experiment_id: str, key: str):
        self.experiments.update_one(
            {"experiment_id": experiment_id},
            {
                "$unset": {f"tags.{key}": ""},
                "$set": {"last_update_time": int(time.time() * 1000)},
            },
        )

    def _doc_to_experiment(self, doc: dict) -> Experiment:
        return Experiment(
            experiment_id=doc["experiment_id"],
            name=doc["name"],
            artifact_location=doc.get("artifact_location"),
            lifecycle_stage=doc.get("lifecycle_stage", "active"),
            tags=[RunTag(k, v) for k, v in doc.get("tags", {}).items()],
            creation_time=doc.get("creation_time"),
            last_update_time=doc.get("last_update_time"),
        )

    # ========================================================================
    # RUNS
    # ========================================================================

    def create_run(
        self, experiment_id: str, user_id: str, start_time: int, tags: list[RunTag]
    ) -> Run:
        run_id = str(uuid.uuid4())
        run_info = RunInfo(
            run_id=run_id,
            experiment_id=experiment_id,
            user_id=user_id,
            status="RUNNING",
            start_time=start_time,
            end_time=None,
            artifact_uri=f"{self.artifact_uri}/{experiment_id}/{run_id}/artifacts",
            lifecycle_stage="active",
        )

        run_doc = {
            "run_id": run_id,
            "experiment_id": experiment_id,
            "user_id": user_id,
            "status": "RUNNING",
            "start_time": start_time,
            "end_time": None,
            "artifact_uri": run_info.artifact_uri,
            "lifecycle_stage": "active",
            "tags": {t.key: t.value for t in tags},
        }
        self.runs.insert_one(run_doc)
        return Run(run_info=run_info, run_data=RunData(metrics=[], params=[], tags=tags))

    def get_run(self, run_id: str) -> Optional[Run]:
        doc = self.runs.find_one({"run_id": run_id})
        return self._doc_to_run(doc) if doc else None

    def update_run_info(
        self, run_id: str, run_status: str, end_time: int, run_name: Optional[str] = None
    ) -> RunInfo:
        update = {"status": run_status, "end_time": end_time}
        if run_name:
            update["run_name"] = run_name
        self.runs.update_one({"run_id": run_id}, {"$set": update})
        run = self.get_run(run_id)
        return run.info if run else None

    def delete_run(self, run_id: str):
        self.runs.update_one({"run_id": run_id}, {"$set": {"lifecycle_stage": "deleted"}})

    def restore_run(self, run_id: str):
        self.runs.update_one({"run_id": run_id}, {"$set": {"lifecycle_stage": "active"}})

    def log_metric(self, run_id: str, metric: Metric):
        metric_doc = {
            "run_id": run_id,
            "key": metric.key,
            "value": metric.value,
            "timestamp": metric.timestamp,
            "step": metric.step,
        }
        self.metrics.insert_one(metric_doc)
        self.runs.update_one(
            {"run_id": run_id},
            {"$set": {f"metrics_latest.{metric.key}": metric.value}},
        )

    def log_param(self, run_id: str, param: Param):
        self.params.replace_one(
            {"run_id": run_id, "key": param.key},
            {"run_id": run_id, "key": param.key, "value": param.value},
            upsert=True,
        )

    def set_tag(self, run_id: str, tag: RunTag):
        self.tags.replace_one(
            {"run_id": run_id, "key": tag.key},
            {"run_id": run_id, "key": tag.key, "value": tag.value},
            upsert=True,
        )
        self.runs.update_one({"run_id": run_id}, {"$set": {f"tags.{tag.key}": tag.value}})

    def get_metric_history(self, run_id: str, metric_key: str) -> list[Metric]:
        cursor = self.metrics.find({"run_id": run_id, "key": metric_key}).sort(
            "timestamp", pymongo.ASCENDING
        )
        return [Metric(d["key"], d["value"], d["timestamp"], d["step"]) for d in cursor]

    def search_runs(
        self,
        experiment_ids: list[str],
        filter_string: str = "",
        run_view_type: int = ViewType.ACTIVE_ONLY,
        max_results: int = SEARCH_MAX_RESULTS_DEFAULT,
        order_by: Optional[list[str]] = None,
        page_token: Optional[str] = None,
    ):
        query = {"experiment_id": {"$in": experiment_ids}}
        if run_view_type == ViewType.ACTIVE_ONLY:
            query["lifecycle_stage"] = "active"
        elif run_view_type == ViewType.DELETED_ONLY:
            query["lifecycle_stage"] = "deleted"

        cursor = self.runs.find(query).limit(max_results)
        runs = [self._doc_to_run(d) for d in cursor]
        return runs, None

    def log_batch(self, run_id: str, metrics: list, params: list, tags: list):
        for metric in metrics:
            self.log_metric(run_id, metric)
        for param in params:
            self.log_param(run_id, param)
        for tag in tags:
            self.set_tag(run_id, tag)

    def log_inputs(self, run_id: str, datasets: list):
        for dataset_input in datasets:
            self.runs.update_one(
                {"run_id": run_id}, {"$push": {"inputs": dataset_input.to_dict()}}
            )

    def log_outputs(self, run_id: str, models: list):
        for model in models:
            self.runs.update_one(
                {"run_id": run_id},
                {"$push": {"outputs": model.to_dict() if hasattr(model, "to_dict") else model}},
            )

    def set_terminated(
        self, run_id: str, status: Optional[str] = None, end_time: Optional[int] = None
    ):
        update = {}
        if status:
            update["status"] = status
        if end_time:
            update["end_time"] = end_time
        else:
            update["end_time"] = int(time.time() * 1000)
        self.runs.update_one({"run_id": run_id}, {"$set": update})

    def _doc_to_run(self, doc: dict) -> Run:
        run_id = doc["run_id"]
        params = [Param(d["key"], d["value"]) for d in self.params.find({"run_id": run_id})]
        tags = [RunTag(d["key"], d["value"]) for d in self.tags.find({"run_id": run_id})]

        metrics = []
        for key in doc.get("metrics_latest", {}).keys():
            history = list(
                self.metrics.find({"run_id": run_id, "key": key})
                .sort("timestamp", -1)
                .limit(1)
            )
            if history:
                m = history[0]
                metrics.append(Metric(m["key"], m["value"], m["timestamp"], m["step"]))

        run_info = RunInfo(
            run_id=run_id,
            experiment_id=doc["experiment_id"],
            user_id=doc.get("user_id", ""),
            status=doc["status"],
            start_time=doc["start_time"],
            end_time=doc.get("end_time"),
            artifact_uri=doc.get("artifact_uri"),
            lifecycle_stage=doc.get("lifecycle_stage", "active"),
        )
        return Run(run_info=run_info, run_data=RunData(metrics=metrics, params=params, tags=tags))

    # ========================================================================
    # TRACES (MLflow 3.x OTel Native)
    # ========================================================================

    def supports_trace_archival(self) -> bool:
        return True

    def start_trace(self, trace_info: TraceInfo) -> TraceInfo:
        trace_doc = {
            "trace_id": trace_info.trace_id,
            "experiment_id": trace_info.trace_location.experiment_id
            if isinstance(trace_info.trace_location, MlflowExperimentLocation)
            else str(trace_info.trace_location),
            "request_time": trace_info.request_time,
            "state": TraceState.IN_PROGRESS.name,
            "request_preview": trace_info.request_preview,
            "response_preview": trace_info.response_preview,
            "client_request_id": trace_info.client_request_id,
            "execution_duration_ms": trace_info.execution_duration,
            "trace_metadata": trace_info.trace_metadata,
            "tags": trace_info.tags,
            "assessments": [a.to_dictionary() for a in trace_info.assessments]
            if trace_info.assessments
            else [],
            "created_at": int(time.time() * 1000),
        }
        self.traces.insert_one(trace_doc)
        return trace_info

    def get_trace_info(self, trace_id: str) -> Optional[TraceInfo]:
        doc = self.traces.find_one({"trace_id": trace_id})
        if not doc:
            return None
        return self._doc_to_trace_info(doc)

    def get_trace(self, trace_id: str, *, allow_partial: bool = False) -> Optional[Trace]:
        trace_info = self.get_trace_info(trace_id)
        if not trace_info:
            return None

        span_docs = list(self.spans.find({"trace_id": trace_id}).sort("start_time_unix_nano", 1))
        spans = [self._doc_to_span(doc) for doc in span_docs]

        return Trace(info=trace_info, data=TraceData(spans=spans))

    def batch_get_traces(
        self, trace_ids: list[str], location: Optional[str] = None
    ) -> list[Trace]:
        traces = []
        for trace_id in trace_ids:
            trace = self.get_trace(trace_id)
            if trace:
                traces.append(trace)
        return traces

    def batch_get_trace_infos(
        self, trace_ids: list[str], location: Optional[str] = None
    ) -> list[TraceInfo]:
        infos = []
        for doc in self.traces.find({"trace_id": {"$in": trace_ids}}):
            infos.append(self._doc_to_trace_info(doc))
        return infos

    def log_spans(self, location: str, spans: list[Span], tracking_uri=None) -> list[Span]:
        stored_spans = []
        for span in spans:
            span_doc = self._span_to_doc(span)
            self.spans.replace_one(
                {"span_id": span_doc["span_id"]},
                span_doc,
                upsert=True,
            )
            stored_spans.append(span)

            if span_doc.get("parent_span_id") is None:
                self.traces.update_one(
                    {"trace_id": span_doc["trace_id"]},
                    {
                        "$set": {
                            "state": TraceState.OK.name,
                            "request_preview": self._extract_preview(span_doc, "inputs"),
                            "response_preview": self._extract_preview(span_doc, "outputs"),
                        }
                    },
                )
        return stored_spans

    def log_spans_async(self, location: str, spans: list[Span]) -> list[Span]:
        return self.log_spans(location, spans)

    def delete_traces(
        self,
        experiment_id: str,
        max_timestamp_millis: Optional[int] = None,
        max_traces: Optional[int] = None,
        trace_ids: Optional[list[str]] = None,
    ) -> int:
        query = {"experiment_id": experiment_id}
        if trace_ids:
            query["trace_id"] = {"$in": trace_ids}
        elif max_timestamp_millis:
            query["request_time"] = {"$lte": max_timestamp_millis}
        else:
            raise MlflowException(
                "Either trace_ids or max_timestamp_millis required", INVALID_PARAMETER_VALUE
            )

        traces_to_delete = list(self.traces.find(query, {"trace_id": 1}))
        deleted_trace_ids = [t["trace_id"] for t in traces_to_delete]

        result = self.traces.delete_many(query)
        self.spans.delete_many({"trace_id": {"$in": deleted_trace_ids}})
        self.assessments.delete_many({"trace_id": {"$in": deleted_trace_ids}})
        return result.deleted_count

    def _delete_traces(
        self,
        experiment_id: str,
        max_timestamp_millis: Optional[int] = None,
        max_traces: Optional[int] = None,
        trace_ids: Optional[list[str]] = None,
    ) -> int:
        return self.delete_traces(experiment_id, max_timestamp_millis, max_traces, trace_ids)

    def search_traces(
        self,
        experiment_ids: Optional[list[str]] = None,
        filter_string: Optional[str] = None,
        max_results: int = SEARCH_TRACES_DEFAULT_MAX_RESULTS,
        order_by: Optional[list[str]] = None,
        page_token: Optional[str] = None,
        model_id: Optional[str] = None,
        locations: Optional[list[str]] = None,
    ) -> tuple[list[TraceInfo], Optional[str]]:
        query = {}
        if experiment_ids:
            query["experiment_id"] = {"$in": experiment_ids}
        if model_id:
            query["trace_metadata.model_id"] = model_id

        if filter_string:
            query.update(self._parse_trace_filter(filter_string))

        cursor = self.traces.find(query).sort("request_time", -1).limit(max_results)
        trace_infos = [self._doc_to_trace_info(doc) for doc in cursor]
        return trace_infos, None

    def set_trace_tag(self, trace_id: str, key: str, value: str):
        self.traces.update_one(
            {"trace_id": trace_id},
            {"$set": {f"tags.{key}": value, "last_updated": int(time.time() * 1000)}},
        )

    def delete_trace_tag(self, trace_id: str, key: str):
        self.traces.update_one({"trace_id": trace_id}, {"$unset": {f"tags.{key}": ""}})

    def link_traces_to_run(self, trace_ids: list[str], run_id: str) -> None:
        self.traces.update_many(
            {"trace_id": {"$in": trace_ids}}, {"$set": {"trace_metadata.run_id": run_id}}
        )

    def unlink_traces_from_run(self, trace_ids: list[str], run_id: str) -> None:
        self.traces.update_many(
            {"trace_id": {"$in": trace_ids}, "trace_metadata.run_id": run_id},
            {"$unset": {"trace_metadata.run_id": ""}},
        )

    def link_prompts_to_trace(
        self, trace_id: str, prompt_versions: list[MLflowPromptVersion]
    ) -> None:
        prompt_data = [{"name": pv.name, "version": pv.version} for pv in prompt_versions]
        self.traces.update_one({"trace_id": trace_id}, {"$set": {"linked_prompts": prompt_data}})

    def archive_traces(
        self,
        *,
        resolved_trace_archival_location: str,
        broader_retention: str,
        long_retention_allowlist: Optional[set[str] | list[str]] = None,
        max_traces_per_pass: Optional[int] = None,
    ) -> int:
        archive_coll = self.db[f"{self.prefix}traces_archive"]
        query = {"state": {"$in": [TraceState.OK.name, TraceState.ERROR.name]}}
        if long_retention_allowlist:
            query["trace_id"] = {"$nin": list(long_retention_allowlist)}

        limit = max_traces_per_pass or 1000
        traces_to_archive = list(self.traces.find(query).limit(limit))
        if not traces_to_archive:
            return 0

        archive_coll.insert_many(traces_to_archive)
        trace_ids = [t["trace_id"] for t in traces_to_archive]
        self.traces.delete_many({"trace_id": {"$in": trace_ids}})
        self.spans.delete_many({"trace_id": {"$in": trace_ids}})
        return len(traces_to_archive)

    def resolve_trace_archival_config(
        self,
        *,
        default_trace_archival_location: str,
        default_retention: str,
    ) -> ResolvedTraceArchivalConfig:
        return ResolvedTraceArchivalConfig(
            location=default_trace_archival_location,
            retention=default_retention,
        )

    def get_online_trace_details(
        self,
        trace_id: str,
        source_inference_table: str,
        source_databricks_request_id: str,
    ) -> str:
        raise MlflowException("Online trace details not supported", INVALID_PARAMETER_VALUE)

    def query_trace_metrics(
        self,
        experiment_ids: list[str],
        view_type: Any,
        metric_name: str,
        aggregations: list[Any],
        dimensions: Optional[list[str]] = None,
        filters: Optional[list[str]] = None,
        time_interval_seconds: Optional[int] = None,
        start_time_ms: Optional[int] = None,
        end_time_ms: Optional[int] = None,
        max_results: int = MAX_RESULTS_QUERY_TRACE_METRICS,
        page_token: Optional[str] = None,
    ) -> PagedList[list[Any]]:
        match_stage = {
            "experiment_id": {"$in": experiment_ids},
            f"attributes.{metric_name}": {"$exists": True},
        }
        if start_time_ms:
            match_stage["request_time"] = {"$gte": start_time_ms}
        if end_time_ms:
            match_stage["request_time"] = {"$lte": end_time_ms}

        pipeline = [
            {"$match": match_stage},
            {"$group": {"_id": "$experiment_id", "values": {"$push": f"$attributes.{metric_name}"}}},
        ]
        results = list(self.traces.aggregate(pipeline))

        data_points = []
        for result in results:
            values = result.get("values", [])
            for agg in aggregations:
                if agg.name == "AVG":
                    val = sum(values) / len(values) if values else 0
                elif agg.name == "SUM":
                    val = sum(values)
                elif agg.name == "COUNT":
                    val = len(values)
                elif agg.name == "MAX":
                    val = max(values) if values else 0
                elif agg.name == "MIN":
                    val = min(values) if values else 0
                else:
                    val = 0
                data_points.append(
                    [
                        {
                            "timestamp_ms": int(time.time() * 1000),
                            "value": val,
                            "group_key": result["_id"],
                        }
                    ]
                )

        return PagedList(data_points, token=None)

    def calculate_trace_filter_correlation(
        self,
        experiment_ids: list[str],
        filter_string1: str,
        filter_string2: str,
        base_filter: Optional[str] = None,
    ) -> TraceFilterCorrelationResult:
        return TraceFilterCorrelationResult(correlation_coefficient=0.0, p_value=1.0)

    # ========================================================================
    # ASSESSMENTS
    # ========================================================================

    def get_assessment(self, assessment_id: str) -> Optional[Assessment]:
        doc = self.assessments.find_one({"assessment_id": assessment_id})
        return Assessment.from_dictionary(doc) if doc else None

    def create_assessment(self, assessment: Assessment) -> Assessment:
        doc = assessment.to_dictionary()
        doc["assessment_id"] = doc.get("assessment_id") or str(uuid.uuid4())
        doc["created_at"] = int(time.time() * 1000)
        self.assessments.insert_one(doc)
        return Assessment.from_dictionary(doc)

    def update_assessment(self, assessment: Assessment) -> Assessment:
        doc = assessment.to_dictionary()
        self.assessments.replace_one(
            {"assessment_id": assessment.assessment_id}, doc, upsert=True
        )
        return assessment

    def delete_assessment(self, assessment_id: str) -> None:
        self.assessments.delete_one({"assessment_id": assessment_id})

    # ========================================================================
    # DATASETS
    # ========================================================================

    def create_dataset(self, dataset) -> Any:
        dataset_id = str(uuid.uuid4())
        doc = {
            "dataset_id": dataset_id,
            "name": dataset.name,
            "digest": dataset.digest,
            "source_type": dataset.source_type,
            "source": dataset.source,
            "schema": dataset.schema.to_dict() if dataset.schema else None,
            "profile": dataset.profile,
            "created_at": int(time.time() * 1000),
        }
        self.datasets.insert_one(doc)
        return dataset

    def get_dataset(self, dataset_id: str) -> Optional[Any]:
        doc = self.datasets.find_one({"dataset_id": dataset_id})
        if not doc:
            return None
        from mlflow.entities import EvaluationDataset
        return EvaluationDataset.from_dict(doc)

    def delete_dataset(self, dataset_id: str) -> None:
        self.datasets.delete_one({"dataset_id": dataset_id})

    def search_datasets(
        self,
        experiment_ids: Optional[list[str]] = None,
        filter_string: Optional[str] = None,
        max_results: int = SEARCH_MAX_RESULTS_DEFAULT,
        order_by: Optional[list[str]] = None,
        page_token: Optional[str] = None,
    ):
        query = {}
        if experiment_ids:
            query["experiment_id"] = {"$in": experiment_ids}
        cursor = self.datasets.find(query).limit(max_results)
        return [self.get_dataset(d["dataset_id"]) for d in cursor], None

    def upsert_dataset_records(self, dataset_id: str, records: list):
        self.datasets.update_one(
            {"dataset_id": dataset_id}, {"$push": {"records": {"$each": records}}}
        )

    def delete_dataset_records(self, dataset_id: str, record_ids: list[str]):
        self.datasets.update_one(
            {"dataset_id": dataset_id},
            {"$pull": {"records": {"record_id": {"$in": record_ids}}}},
        )

    def set_dataset_tags(self, dataset_id: str, tags: dict):
        self.datasets.update_one(
            {"dataset_id": dataset_id}, {"$set": {f"tags.{k}": v for k, v in tags.items()}}
        )

    def delete_dataset_tag(self, dataset_id: str, key: str):
        self.datasets.update_one({"dataset_id": dataset_id}, {"$unset": {f"tags.{key}": ""}})

    def get_dataset_experiment_ids(self, dataset_id: str) -> list[str]:
        doc = self.datasets.find_one({"dataset_id": dataset_id}, {"experiment_ids": 1})
        return doc.get("experiment_ids", []) if doc else []

    def add_dataset_to_experiments(self, dataset_id: str, experiment_ids: list[str]):
        self.datasets.update_one(
            {"dataset_id": dataset_id},
            {"$addToSet": {"experiment_ids": {"$each": experiment_ids}}},
        )

    def remove_dataset_from_experiments(self, dataset_id: str, experiment_ids: list[str]):
        self.datasets.update_one(
            {"dataset_id": dataset_id}, {"$pull": {"experiment_ids": {"$in": experiment_ids}}}
        )

    # ========================================================================
    # LOGGED MODELS
    # ========================================================================

    def create_logged_model(
        self,
        experiment_id: str,
        name: str,
        source_run_id: Optional[str] = None,
        tags: Optional[dict] = None,
        params: Optional[dict] = None,
        metrics: Optional[dict] = None,
    ) -> Any:
        model_id = str(uuid.uuid4())
        now_ms = int(time.time() * 1000)
        doc = {
            "model_id": model_id,
            "experiment_id": experiment_id,
            "name": name,
            "source_run_id": source_run_id,
            "tags": tags or {},
            "params": params or {},
            "metrics": metrics or {},
            "status": "PENDING",
            "creation_time": now_ms,
            "last_update_time": now_ms,
        }
        self.logged_models.insert_one(doc)
        from mlflow.entities import LoggedModel
        return LoggedModel(
            model_id=model_id,
            experiment_id=experiment_id,
            name=name,
            creation_time=now_ms,
            last_update_time=now_ms,
        )

    def get_logged_model(self, model_id: str) -> Optional[Any]:
        doc = self.logged_models.find_one({"model_id": model_id})
        if not doc:
            return None
        from mlflow.entities import LoggedModel
        return LoggedModel(
            model_id=doc["model_id"],
            experiment_id=doc["experiment_id"],
            name=doc["name"],
            creation_time=doc["creation_time"],
            last_update_time=doc["last_update_time"],
        )

    def search_logged_models(
        self,
        experiment_ids: Optional[list[str]] = None,
        filter_string: Optional[str] = None,
        max_results: int = SEARCH_MAX_RESULTS_DEFAULT,
        order_by: Optional[list[str]] = None,
        page_token: Optional[str] = None,
    ):
        query = {}
        if experiment_ids:
            query["experiment_id"] = {"$in": experiment_ids}
        cursor = self.logged_models.find(query).limit(max_results)
        from mlflow.entities import LoggedModel
        models = []
        for doc in cursor:
            models.append(
                LoggedModel(
                    model_id=doc["model_id"],
                    experiment_id=doc["experiment_id"],
                    name=doc["name"],
                    creation_time=doc["creation_time"],
                    last_update_time=doc["last_update_time"],
                )
            )
        return models, None

    def finalize_logged_model(self, model_id: str, status: str) -> Any:
        self.logged_models.update_one(
            {"model_id": model_id},
            {"$set": {"status": status, "last_update_time": int(time.time() * 1000)}},
        )
        return self.get_logged_model(model_id)

    def set_logged_model_tags(self, model_id: str, tags: dict) -> None:
        update = {f"tags.{k}": v for k, v in tags.items()}
        update["last_update_time"] = int(time.time() * 1000)
        self.logged_models.update_one({"model_id": model_id}, {"$set": update})

    def set_model_versions_tags(self, model_id: str, version: str, tags: dict) -> None:
        self.model_versions.update_one(
            {"name": model_id, "version": version},
            {"$set": {f"tags.{k}": v for k, v in tags.items()}},
        )

    def delete_logged_model_tag(self, model_id: str, key: str) -> None:
        self.logged_models.update_one(
            {"model_id": model_id},
            {
                "$unset": {f"tags.{key}": ""},
                "$set": {"last_update_time": int(time.time() * 1000)},
            },
        )

    def delete_logged_model(self, model_id: str) -> None:
        self.logged_models.delete_one({"model_id": model_id})

    # ========================================================================
    # MODEL REGISTRY (MongoDB-backed)
    # ========================================================================

    def create_registered_model(self, name: str, tags=None, description=None):
        if self.registered_models.find_one({"name": name}):
            raise MlflowException(
                f"Registered model '{name}' already exists", INVALID_PARAMETER_VALUE
            )

        doc = {
            "name": name,
            "description": description,
            "tags": {t.key: t.value for t in (tags or [])},
            "creation_time": int(time.time() * 1000),
            "last_updated_time": int(time.time() * 1000),
        }
        self.registered_models.insert_one(doc)
        from mlflow.entities.model_registry import RegisteredModel
        return RegisteredModel(name=name)

    def get_registered_model(self, name: str):
        doc = self.registered_models.find_one({"name": name})
        if not doc:
            raise MlflowException(
                f"Registered model '{name}' not found", RESOURCE_DOES_NOT_EXIST
            )
        from mlflow.entities.model_registry import RegisteredModel
        return RegisteredModel(name=name)

    def update_registered_model(self, name: str, description=None):
        update = {"last_updated_time": int(time.time() * 1000)}
        if description:
            update["description"] = description
        self.registered_models.update_one({"name": name}, {"$set": update})
        return self.get_registered_model(name)

    def rename_registered_model(self, name: str, new_name: str):
        self.registered_models.update_one(
            {"name": name},
            {"$set": {"name": new_name, "last_updated_time": int(time.time() * 1000)}},
        )
        return self.get_registered_model(new_name)

    def delete_registered_model(self, name: str):
        self.registered_models.delete_one({"name": name})
        self.model_versions.delete_many({"name": name})

    def search_registered_models(
        self, filter_string=None, max_results=100, order_by=None, page_token=None
    ):
        cursor = self.registered_models.find().limit(max_results)
        from mlflow.entities.model_registry import RegisteredModel
        models = []
        for doc in cursor:
            models.append(RegisteredModel(name=doc["name"]))
        return models, None

    def get_latest_versions(self, name: str, stages=None):
        query = {"name": name}
        if stages:
            query["current_stage"] = {"$in": stages if isinstance(stages, list) else [stages]}
        cursor = self.model_versions.find(query).sort("version", -1)
        from mlflow.entities.model_registry import ModelVersion
        return [ModelVersion(name=d["name"], version=d["version"]) for d in cursor]

    def create_model_version(
        self, name: str, source: str, run_id=None, tags=None, run_link=None, description=None
    ):
        latest = self.model_versions.find_one({"name": name}, sort=[("version", -1)])
        version = str(int(latest["version"]) + 1) if latest else "1"

        doc = {
            "name": name,
            "version": version,
            "source": source,
            "run_id": run_id,
            "run_link": run_link,
            "description": description,
            "tags": {t.key: t.value for t in (tags or [])},
            "current_stage": "None",
            "creation_time": int(time.time() * 1000),
            "last_updated_time": int(time.time() * 1000),
            "status": "READY",
        }
        self.model_versions.insert_one(doc)
        from mlflow.entities.model_registry import ModelVersion
        return ModelVersion(name=name, version=version)

    def get_model_version(self, name: str, version: str):
        doc = self.model_versions.find_one({"name": name, "version": version})
        if not doc:
            raise MlflowException(
                f"Model version {name}/{version} not found", RESOURCE_DOES_NOT_EXIST
            )
        from mlflow.entities.model_registry import ModelVersion
        return ModelVersion(name=name, version=version)

    def update_model_version(self, name: str, version: str, description=None):
        update = {"last_updated_time": int(time.time() * 1000)}
        if description:
            update["description"] = description
        self.model_versions.update_one({"name": name, "version": version}, {"$set": update})
        return self.get_model_version(name, version)

    def transition_model_version_stage(
        self, name: str, version: str, stage: str, archive_existing_versions=False
    ):
        if archive_existing_versions:
            self.model_versions.update_many(
                {"name": name, "current_stage": stage}, {"$set": {"current_stage": "Archived"}}
            )
        self.model_versions.update_one(
            {"name": name, "version": version},
            {"$set": {"current_stage": stage, "last_updated_time": int(time.time() * 1000)}},
        )
        return self.get_model_version(name, version)

    def delete_model_version(self, name: str, version: str):
        self.model_versions.delete_one({"name": name, "version": version})

    def search_model_versions(
        self, filter_string=None, max_results=10000, order_by=None, page_token=None
    ):
        cursor = self.model_versions.find().limit(max_results)
        from mlflow.entities.model_registry import ModelVersion
        versions = []
        for doc in cursor:
            versions.append(ModelVersion(name=doc["name"], version=doc["version"]))
        return versions, None

    def get_model_version_download_uri(self, name: str, version: str):
        doc = self.model_versions.find_one({"name": name, "version": version})
        if not doc:
            raise MlflowException("Model version not found", RESOURCE_DOES_NOT_EXIST)
        return doc.get("source", "")

    def set_model_version_tag(self, name: str, version: str, key: str, value: str):
        self.model_versions.update_one(
            {"name": name, "version": version},
            {"$set": {f"tags.{key}": value, "last_updated_time": int(time.time() * 1000)}},
        )

    def delete_model_version_tag(self, name: str, version: str, key: str):
        self.model_versions.update_one(
            {"name": name, "version": version},
            {
                "$unset": {f"tags.{key}": ""},
                "$set": {"last_updated_time": int(time.time() * 1000)},
            },
        )

    def set_registered_model_tag(self, name: str, key: str, value: str):
        self.registered_models.update_one(
            {"name": name},
            {"$set": {f"tags.{key}": value, "last_updated_time": int(time.time() * 1000)}},
        )

    def delete_registered_model_tag(self, name: str, key: str):
        self.registered_models.update_one(
            {"name": name},
            {
                "$unset": {f"tags.{key}": ""},
                "$set": {"last_updated_time": int(time.time() * 1000)},
            },
        )

    # ========================================================================
    # SCORERS / REVIEW QUEUES / LABEL SCHEMAS
    # ========================================================================

    def register_scorer(self, name: str, scorer_type: str, config: dict):
        scorer_id = str(uuid.uuid4())
        doc = {
            "scorer_id": scorer_id,
            "name": name,
            "scorer_type": scorer_type,
            "config": config,
            "created_at": int(time.time() * 1000),
        }
        self.scorers.insert_one(doc)
        return scorer_id

    def list_scorers(self, experiment_id: str):
        return list(self.scorers.find({"experiment_id": experiment_id}))

    def list_scorers_across_experiments(self, experiment_ids: list[str]):
        return list(self.scorers.find({"experiment_id": {"$in": experiment_ids}}))

    def get_scorer(self, scorer_id: str):
        return self.scorers.find_one({"scorer_id": scorer_id})

    def list_scorer_versions(self, scorer_id: str):
        return []

    def delete_scorer(self, scorer_id: str):
        self.scorers.delete_one({"scorer_id": scorer_id})

    def upsert_online_scoring_config(self, experiment_id: str, config: dict):
        self.scorers.update_one(
            {"experiment_id": experiment_id, "name": config.get("name")},
            {"$set": {**config, "updated_at": int(time.time() * 1000)}},
            upsert=True,
        )

    def get_online_scoring_configs(self, experiment_id: str):
        return list(self.scorers.find({"experiment_id": experiment_id, "config_type": "online"}))

    def get_active_online_scorers(self, experiment_id: str):
        return list(
            self.scorers.find({"experiment_id": experiment_id, "config_type": "online", "active": True})
        )

    def create_label_schema(self, name: str, schema: dict):
        schema_id = str(uuid.uuid4())
        doc = {
            "schema_id": schema_id,
            "name": name,
            "schema": schema,
            "created_at": int(time.time() * 1000),
        }
        self.label_schemas.insert_one(doc)
        return schema_id

    def get_label_schema(self, schema_id: str):
        return self.label_schemas.find_one({"schema_id": schema_id})

    def get_label_schema_by_name(self, name: str):
        return self.label_schemas.find_one({"name": name})

    def list_label_schemas(self, experiment_id: str):
        return list(self.label_schemas.find({"experiment_id": experiment_id}))

    def update_label_schema(self, schema_id: str, updates: dict):
        self.label_schemas.update_one(
            {"schema_id": schema_id},
            {"$set": {**updates, "updated_at": int(time.time() * 1000)}},
        )

    def delete_label_schema(self, schema_id: str):
        self.label_schemas.delete_one({"schema_id": schema_id})

    def create_review_queue(self, name: str, config: dict):
        queue_id = str(uuid.uuid4())
        doc = {
            "queue_id": queue_id,
            "name": name,
            "config": config,
            "created_at": int(time.time() * 1000),
        }
        self.review_queues.insert_one(doc)
        return queue_id

    def get_or_create_user_queue(self, user_id: str, queue_name: str):
        queue = self.review_queues.find_one({"name": queue_name})
        if not queue:
            return self.create_review_queue(queue_name, {"user_id": user_id})
        return queue["queue_id"]

    def get_review_queue(self, queue_id: str):
        return self.review_queues.find_one({"queue_id": queue_id})

    def get_review_queue_by_name(self, name: str):
        return self.review_queues.find_one({"name": name})

    def list_review_queues(self, experiment_id: str):
        return list(self.review_queues.find({"experiment_id": experiment_id}))

    def update_review_queue(self, queue_id: str, updates: dict):
        self.review_queues.update_one(
            {"queue_id": queue_id},
            {"$set": {**updates, "updated_at": int(time.time() * 1000)}},
        )

    def delete_review_queue(self, queue_id: str):
        self.review_queues.delete_one({"queue_id": queue_id})

    def add_items_to_review_queue(self, queue_id: str, trace_ids: list[str]):
        self.review_queues.update_one(
            {"queue_id": queue_id},
            {
                "$addToSet": {
                    "items": {
                        "$each": [{"trace_id": tid, "status": "PENDING"} for tid in trace_ids]
                    }
                }
            },
        )

    def remove_items_from_review_queue(self, queue_id: str, trace_ids: list[str]):
        self.review_queues.update_one(
            {"queue_id": queue_id}, {"$pull": {"items": {"trace_id": {"$in": trace_ids}}}}
        )

    def list_review_queue_items(self, queue_id: str, status: str = None):
        queue = self.review_queues.find_one({"queue_id": queue_id})
        if not queue:
            return []
        items = queue.get("items", [])
        if status:
            items = [i for i in items if i.get("status") == status]
        return items

    def set_review_queue_item_status(self, item_id: str, status: str):
        self.review_queues.update_one(
            {"items.trace_id": item_id}, {"$set": {"items.$.status": status}}
        )

    # ========================================================================
    # ISSUES
    # ========================================================================

    def create_issue(
        self,
        experiment_id: str,
        trace_id: str,
        issue_type: str,
        description: str,
        severity: str = "LOW",
        status: str = "OPEN",
    ):
        issue_id = str(uuid.uuid4())
        doc = {
            "issue_id": issue_id,
            "experiment_id": experiment_id,
            "trace_id": trace_id,
            "issue_type": issue_type,
            "description": description,
            "severity": severity,
            "status": status,
            "created_at": int(time.time() * 1000),
        }
        self.issues.insert_one(doc)
        return issue_id

    def get_issue(self, issue_id: str):
        return self.issues.find_one({"issue_id": issue_id})

    def update_issue(self, issue_id: str, updates: dict):
        self.issues.update_one(
            {"issue_id": issue_id},
            {"$set": {**updates, "updated_at": int(time.time() * 1000)}},
        )

    def search_issues(self, experiment_id: str, trace_id: str = None):
        query = {"experiment_id": experiment_id}
        if trace_id:
            query["trace_id"] = trace_id
        return list(self.issues.find(query))

    # ========================================================================
    # ASYNC LOGGING
    # ========================================================================

    def log_metric_async(self, run_id: str, metric: Metric):
        return self.log_metric(run_id, metric)

    def log_param_async(self, run_id: str, param: Param):
        return self.log_param(run_id, param)

    def set_tag_async(self, run_id: str, tag: RunTag):
        return self.set_tag(run_id, tag)

    def log_batch_async(self, run_id: str, metrics: list, params: list, tags: list):
        return self.log_batch(run_id, metrics, params, tags)

    def end_async_logging(self):
        pass

    def flush_async_logging(self):
        pass

    def shut_down_async_logging(self):
        pass

    # ========================================================================
    # PROMPT REGISTRY (Custom MongoDB-backed)
    # ========================================================================

    def register_prompt(
        self,
        name: str,
        template: str,
        commit_message: str = "",
        tags: Optional[dict] = None,
        model_config: Optional[dict] = None,
        response_format: Optional[Any] = None,
        created_by: str = "unknown",
    ):
        """Register a prompt in the MongoDB Prompt Registry."""
        return self.prompt_registry.register_prompt(
            name=name,
            template=template,
            commit_message=commit_message,
            tags=tags,
            model_config=model_config,
            response_format=response_format,
            created_by=created_by,
        )

    def load_prompt(self, name_or_uri: str, version: Optional[int | str] = None, allow_missing: bool = False):
        """Load a prompt from the MongoDB Prompt Registry."""
        return self.prompt_registry.load_prompt(name_or_uri, version, allow_missing)

    def search_prompts(
        self,
        filter_string: Optional[str] = None,
        max_results: int = 100,
        page_token: Optional[str] = None,
    ):
        """Search prompts in the MongoDB Prompt Registry."""
        return self.prompt_registry.search_prompts(filter_string, max_results, page_token)

    def set_prompt_alias(self, name: str, alias: str, version: int):
        """Set an alias for a prompt version."""
        return self.prompt_registry.set_prompt_alias(name, alias, version)

    def delete_prompt_alias(self, name: str, alias: str):
        """Delete a prompt alias."""
        return self.prompt_registry.delete_prompt_alias(name, alias)

    def delete_prompt_version(self, name: str, version: int):
        """Delete a specific prompt version."""
        return self.prompt_registry.delete_prompt_version(name, version)

    def delete_prompt(self, name: str):
        """Delete a prompt and all versions."""
        return self.prompt_registry.delete_prompt(name)

    # ========================================================================
    # OTEL SPAN SERIALIZATION
    # ========================================================================

    def _span_to_doc(self, span: Span) -> dict:
        """Convert MLflow Span to MongoDB document."""
        otel_span = span._span

        return {
            "trace_id": span.trace_id,
            "span_id": span.span_id,
            "parent_span_id": span.parent_id,
            "name": span.name,
            "start_time_unix_nano": span.start_time_ns,
            "end_time_unix_nano": span.end_time_ns,
            "status": {
                "code": span.status.status_code.value,
                "message": span.status.description,
            },
            "attributes": dict(otel_span.attributes) if otel_span.attributes else {},
            "events": [
                {
                    "name": event.name,
                    "time_unix_nano": event.timestamp,
                    "attributes": dict(event.attributes)
                    if hasattr(event, "attributes")
                    else {},
                }
                for event in span.events
            ],
            "links": [
                {
                    "context": {
                        "trace_id": (
                            link.context.trace_id
                            if hasattr(link.context, "trace_id")
                            else link.trace_id
                        ),
                        "span_id": (
                            link.context.span_id
                            if hasattr(link.context, "span_id")
                            else link.span_id
                        ),
                    },
                    "attributes": dict(link.attributes) if link.attributes else {},
                }
                for link in span.links
            ],
            "span_type": getattr(span, "span_type", "UNKNOWN"),
            "inputs": getattr(span, "inputs", None),
            "outputs": getattr(span, "outputs", None),
        }

    def _doc_to_span(self, doc: dict) -> Span:
        """Convert MongoDB document back to MLflow Span."""
        from opentelemetry.sdk.trace import ReadableSpan as OTelReadableSpan
        from opentelemetry.sdk.trace import Event as OTelEvent
        from opentelemetry.trace import SpanContext, TraceFlags
        from opentelemetry.trace import Status as OTelStatus

        trace_id_val = doc.get("trace_id", "0")
        span_id_val = doc.get("span_id", "0")
        parent_id = doc.get("parent_span_id")

        try:
            trace_id_int = (
                int(trace_id_val, 16)
                if len(trace_id_val) <= 32
                else int.from_bytes(__import__("base64").b64decode(trace_id_val), "big")
            )
        except (ValueError, __import__("base64").binascii.Error):
            trace_id_int = hash(trace_id_val) & ((1 << 128) - 1)

        try:
            span_id_int = (
                int(span_id_val, 16)
                if len(span_id_val) <= 16
                else int.from_bytes(__import__("base64").b64decode(span_id_val), "big")
            )
        except (ValueError, __import__("base64").binascii.Error):
            span_id_int = hash(span_id_val) & ((1 << 64) - 1)

        span_context = SpanContext(
            trace_id=trace_id_int,
            span_id=span_id_int,
            is_remote=False,
            trace_flags=TraceFlags(1),
        )

        parent_context = None
        if parent_id:
            try:
                parent_span_id_int = (
                    int(parent_id, 16)
                    if len(parent_id) <= 16
                    else int.from_bytes(__import__("base64").b64decode(parent_id), "big")
                )
            except (ValueError, __import__("base64").binascii.Error):
                parent_span_id_int = hash(parent_id) & ((1 << 64) - 1)
            parent_context = SpanContext(
                trace_id=trace_id_int,
                span_id=parent_span_id_int,
                is_remote=False,
                trace_flags=TraceFlags(1),
            )

        events = []
        for evt_doc in doc.get("events", []):
            events.append(
                OTelEvent(
                    name=evt_doc["name"],
                    timestamp=evt_doc.get("time_unix_nano", 0),
                    attributes=evt_doc.get("attributes", {}),
                )
            )

        from mlflow.entities.span_status import SpanStatusCode

        status_code = SpanStatusCode.OK
        if doc.get("status", {}).get("code") == 2:
            status_code = SpanStatusCode.ERROR

        otel_span = OTelReadableSpan(
            name=doc["name"],
            context=span_context,
            parent=parent_context,
            start_time=doc["start_time_unix_nano"],
            end_time=doc.get("end_time_unix_nano"),
            status=OTelStatus(status_code),
            attributes=doc.get("attributes", {}),
            events=events,
        )

        return Span(otel_span)

    def _doc_to_trace_info(self, doc: dict) -> TraceInfo:
        """Convert MongoDB document to TraceInfo."""
        trace_location = MlflowExperimentLocation(experiment_id=doc["experiment_id"])

        assessments = []
        if "assessments" in doc:
            assessments = [Assessment.from_dictionary(a) for a in doc["assessments"]]

        return TraceInfo(
            trace_id=doc["trace_id"],
            trace_location=trace_location,
            request_time=doc.get("request_time", 0),
            state=TraceState[doc.get("state", "STATE_UNSPECIFIED")],
            request_preview=doc.get("request_preview"),
            response_preview=doc.get("response_preview"),
            client_request_id=doc.get("client_request_id"),
            execution_duration=doc.get("execution_duration_ms"),
            trace_metadata=doc.get("trace_metadata", {}),
            tags=doc.get("tags", {}),
            assessments=assessments,
        )

    def _parse_trace_filter(self, filter_string: str) -> dict:
        """Parse MLflow trace filter to MongoDB query."""
        query = {}
        return query

    def _extract_preview(self, span_doc: dict, field: str) -> Optional[str]:
        """Extract preview text from span."""
        attrs = span_doc.get("attributes", {})
        key_map = {"inputs": "mlflow.trace.inputs", "outputs": "mlflow.trace.outputs"}
        key = key_map.get(field)
        if key and key in attrs:
            val = attrs[key]
            return val[:500] if isinstance(val, str) else json.dumps(val)[:500]
        return None
