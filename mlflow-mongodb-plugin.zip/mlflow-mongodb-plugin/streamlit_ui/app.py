"""Streamlit dashboard for MongoDB MLflow traces (fallback if MLflow UI has issues)."""

import streamlit as st
import pandas as pd
from pymongo import MongoClient
from datetime import datetime

st.set_page_config(page_title="MongoDB MLflow Viewer", layout="wide")

# Sidebar
st.sidebar.title("MongoDB MLflow")
mongo_uri = st.sidebar.text_input("MongoDB URI", "mongodb://localhost:27017")
db_name = st.sidebar.text_input("Database", "mlflow_db")
prefix = st.sidebar.text_input("Collection Prefix", "")

client = MongoClient(mongo_uri)
db = client[db_name]

# Main content
st.title("MLflow MongoDB Dashboard")

tab1, tab2, tab3, tab4 = st.tabs(["Experiments", "Runs", "Traces", "Prompts"])

with tab1:
    st.header("Experiments")
    experiments = list(db[f"{prefix}experiments"].find())
    if experiments:
        df = pd.DataFrame([
            {
                "ID": e["experiment_id"],
                "Name": e["name"],
                "Status": e.get("lifecycle_stage", "active"),
                "Created": datetime.fromtimestamp(e.get("creation_time", 0) / 1000),
            }
            for e in experiments
        ])
        st.dataframe(df, use_container_width=True)
    else:
        st.info("No experiments found")

with tab2:
    st.header("Runs")
    runs = list(db[f"{prefix}runs"].find().limit(100))
    if runs:
        df = pd.DataFrame([
            {
                "Run ID": r["run_id"][:8] + "...",
                "Experiment": r["experiment_id"][:8] + "...",
                "Status": r["status"],
                "Start Time": datetime.fromtimestamp(r["start_time"] / 1000) if r.get("start_time") else None,
            }
            for r in runs
        ])
        st.dataframe(df, use_container_width=True)
    else:
        st.info("No runs found")

with tab3:
    st.header("Traces")
    traces = list(db[f"{prefix}traces"].find().sort("request_time", -1).limit(100))
    if traces:
        df = pd.DataFrame([
            {
                "Trace ID": t["trace_id"][:12] + "...",
                "State": t.get("state"),
                "Time": datetime.fromtimestamp(t.get("request_time", 0) / 1000),
                "Duration (ms)": t.get("execution_duration_ms"),
                "Preview": t.get("request_preview", "")[:50],
            }
            for t in traces
        ])
        st.dataframe(df, use_container_width=True)

        # Trace detail
        trace_id = st.selectbox("Select Trace", [t["trace_id"] for t in traces])
        if trace_id:
            spans = list(db[f"{prefix}spans"].find({"trace_id": trace_id}).sort("start_time_unix_nano", 1))
            for span in spans:
                with st.expander(f"📍 {span['name']} ({span.get('span_type', 'UNKNOWN')})"):
                    st.json({
                        "span_id": span["span_id"],
                        "parent": span.get("parent_span_id"),
                        "duration_ms": (span.get("end_time_unix_nano", 0) - span["start_time_unix_nano"]) / 1e6,
                        "attributes": span.get("attributes", {}),
                        "inputs": span.get("inputs"),
                        "outputs": span.get("outputs"),
                    })
    else:
        st.info("No traces found")

with tab4:
    st.header("Prompt Registry")
    prompts = list(db["prompts"].find())
    if prompts:
        for p in prompts:
            with st.expander(f"📝 {p['name']} (latest: v{p.get('latest_version', 0)})"):
                versions = list(db["prompt_versions"].find({"name": p["name"]}).sort("version", -1))
                for v in versions:
                    st.write(f"**v{v['version']}** - {v.get('commit_message', '')}")
                    st.code(v["template"] if isinstance(v["template"], str) else str(v["template"]))
    else:
        st.info("No prompts registered")
