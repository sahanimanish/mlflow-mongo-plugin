from setuptools import setup, find_packages

setup(
    name="mlflow-mongodb-plugin",
    version="0.3.0",
    packages=find_packages(),
    install_requires=[
        "mlflow>=3.0.0",
        "pymongo>=4.5.0",
        "opentelemetry-api>=1.20.0",
        "opentelemetry-sdk>=1.20.0",
        "jinja2>=3.1.0",
    ],
    entry_points={
        "mlflow.tracking_store": [
            "mongodb=mlflow_mongodb.tracking_store:MongoDBTrackingStore"
        ],
    },
    python_requires=">=3.9",
)
